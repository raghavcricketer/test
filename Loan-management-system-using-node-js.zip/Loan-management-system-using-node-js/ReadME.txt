This app is built with nodeJs express framework and sql database. In the forntend i have used html css and bootstrap. 

This app can help keep record of customer who has taken loan. Admin can give loan by registering a customer with his information.
Admin can add schemes to the system.

Customer info:
 
 Customer has to give his name , address, contact ,image and asset(what he has to take the loan) and the price off his asset.

 if his asset is good then he can take the loan.

 After that system will create installments dates for the customer and will print a pdf to give to the customer.
 customer needs to give installments on time if he miss the date of installment he have to give fine. if he delay a month to pay he has to give fine 2% of his installment amount.

 Admin can see all the customers info and loan info.
 Admin can edit , delete information.
 Admin can search for customer ID and can see their history.

 If you want to run this software in your pc follow  the steps: clone or download this from here.

 Take the database from database folder and import the databse to your database and keep the name same given in the file.


 #you must need to have node installed on your pc.
 #after downloading open the app in vscode(your editor) and run command from terminal > npm install.

 if will install al the dependencies and then run the server.js in your browser, hit server 3000 to see the result.


 
 
